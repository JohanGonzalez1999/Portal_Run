using UnityEngine;

public class WaterCollider : MonoBehaviour
{

    void OnCollisionEnter2D(Collision2D otherObject)
    {
        // Checking if the "other" object is Player_1
        if(otherObject.gameObject.CompareTag("Player_1"))
        {
            Vector2 newPosition = otherObject.gameObject.transform.position;
            newPosition = new Vector2 (25, 2);
            otherObject.gameObject.transform.position = newPosition;
        }

        else if(otherObject.gameObject.CompareTag("Player_2"))
        {
            Vector2 newPosition = otherObject.gameObject.transform.position;
            newPosition = new Vector2 (25, 2);
            otherObject.gameObject.transform.position = newPosition;
        }

    }

}
