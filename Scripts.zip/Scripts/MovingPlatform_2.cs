using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingPlatform_2 : MonoBehaviour
{

    float directionY, movementSpeed = 4f;
    bool MoveUp = true;

    // Update is called once per frame
    void Update()
    {
        if(transform.position.y >= -28f)
        {
            MoveUp = false;
        }

        if(transform.position.y <= -34f)
        {
            MoveUp = true;
        }

        if(MoveUp)
        {
            transform.position = new Vector2(transform.position.x, transform.position.y + movementSpeed * Time.deltaTime);
        }
        else
        {
            transform.position = new Vector2(transform.position.x, transform.position.y - movementSpeed * Time.deltaTime);
        }
        
    }
}
